// Newest publication first. The home page shows up to three real articles.
export const news = {
  ru: [
    {
      slug: 'early-access', category: 'Ранний доступ', title: 'Скоро отправимся в ранний доступ',
      image: 'news/early-access-cover.png', imageAlt: 'Lighthouse Beyond — маяк в ночном море',
      summary: 'Готовимся открыть маяк первым игрокам. Показываем свежие скриншоты и игровой процесс перед выходом в ранний доступ.',
      lead: 'Lighthouse Beyond Idle готовится к раннему доступу на Android. Скоро у моря появятся первые смотрители — и мы хотим показать, какое путешествие их ждёт.',
      paragraphs: [
        'Вы направляете луч маяка, проявляете силуэты в тумане и собираете Свет для улучшений. Мастерская помогает развивать ручной луч и автоматику, а синий спектр открывает отражения, которых не видно в обычном свете.',
        'Постепенно море складывается в историю: необычные встречи оставляют записи в Журнале, карта ведёт к новым участкам, а Великий шторм начинает следующее плавание. Сохранённые осколки позволяют развивать Оптику и возвращаться к маяку с новыми возможностями.'
      ],
      videoTitle: 'Полминуты у маяка',
      videoBody: 'В этом ролике — живой игровой процесс: проявление объектов, смена спектра, улучшение лампы, Оптика и подготовка к шторму. Это та же запись, которую мы подготовили для карточек магазинов.',
      videoCaption: 'Русский интерфейс · 30 секунд игрового процесса',
      galleryTitle: 'Посмотрите на игру ближе',
      galleryIntro: 'Скриншоты из набора для Google Play и RuStore. Нажмите на изображение, чтобы открыть его целиком.',
      screenshots: [
        ['store-01-sea.png', 'Обычный луч и первые проявления'],
        ['store-08-blue-spectrum.png', 'Синий спектр и скрытые отражения'],
        ['store-02-workshop.png', 'Мастерская маяка'],
        ['store-06-optics.png', 'Оптика и новые возможности'],
        ['store-07-storm.png', 'Перед Великим штормом'],
        ['store-03-journal.png', 'Журнал найденных историй'],
        ['store-04-map.png', 'Карта морского пути'],
        ['store-05-story.png', 'Встречи за туманом']
      ],
      closingTitle: 'Встретимся на берегу',
      closing: 'В раннем доступе будем дорабатывать игру вместе с вами: слушать впечатления о темпе путешествия, удобстве управления и историях моря. Точную дату и ссылки на Google Play и RuStore объявим здесь, когда откроется доступ.'
    },
    {
      slug: 'development-begins', category: 'Дневник разработки', title: 'Мы начали разработку Lighthouse Beyond Idle',
      image: 'news/development-cover.png', imageAlt: 'Первый свет маяка открывает путь в туманном море',
      summary: 'Всё началось с маяка, луча и силуэтов в тумане. Рассказываем об идее игры и показываем первые кадры прототипа.',
      lead: 'Мы начали делать Lighthouse Beyond Idle — атмосферную игру о смотрителе маяка на краю реальности. Здесь свет помогает не только видеть: он возвращает морю забытые очертания.',
      paragraphs: [
        'В основе — простое действие: направить луч на силуэт и проявить то, что скрывает туман. Найденный Свет помогает улучшать маяк, усиливать лампу и развивать автоматику. Хотим, чтобы короткие возвращения к морю складывались в большое, неспешное путешествие.',
        'Первые версии были посвящены самому важному: ощущению луча, появлению кораблей, понятным улучшениям и сохранению прогресса. Мастерская и Журнал уже намечали будущий ритм игры — находить, улучшать и узнавать историю этого места.'
      ],
      galleryTitle: 'Первые кадры прототипа',
      galleryIntro: 'Так выглядела версия 0.2: раннее море, Мастерская и Журнал. Это сохранённые снимки первых сборок — интерфейс и оформление с тех пор изменились. Нажмите на кадр, чтобы рассмотреть его в полном размере.',
      screenshots: [
        ['prototype-sea.png', 'Прототип 0.2 · море и первый луч'],
        ['prototype-workshop.png', 'Прототип 0.2 · первые улучшения'],
        ['prototype-journal.png', 'Прототип 0.2 · Журнал открытий']
      ],
      closingTitle: 'Один сигнал за раз',
      closing: 'Дальше нам предстоит наполнить море новыми встречами, дать свету новые возможности и найти правильный темп путешествия. Будем делиться изменениями здесь — от первых силуэтов до следующего горизонта.'
    }
  ],
  en: [
    {
      slug: 'early-access', category: 'Early access', title: 'Early access is on the horizon',
      image: 'news/early-access-cover.png', imageAlt: 'Lighthouse Beyond — a lighthouse on the night sea',
      summary: 'We’re getting ready to welcome our first keepers. Take a look at the latest screenshots and gameplay ahead of early access.',
      lead: 'Lighthouse Beyond Idle is getting ready for early access on Android. Soon, the sea will welcome its first keepers. Here’s a look at the journey waiting for you.',
      paragraphs: [
        'Guide a lighthouse beam, reveal silhouettes in the mist and gather Light to improve your lighthouse. The Workshop develops your manual beam and automation, while the blue spectrum reveals reflections hidden from ordinary light.',
        'Little by little, the sea becomes a story. Unusual encounters leave entries in your Journal, the map leads to new sectors, and a Great Storm begins another voyage. The Shards you keep help you develop Optics and return to the lighthouse with new possibilities.'
      ],
      videoTitle: 'Half a minute by the lighthouse',
      videoBody: 'Watch actual gameplay: objects appearing, a spectrum change, a Lamp upgrade, Optics and preparations for a storm. This is the same recording we prepared for our store listings.',
      videoCaption: 'English interface · 30 seconds of gameplay',
      galleryTitle: 'Take a closer look',
      galleryIntro: 'Screenshots prepared for Google Play and RuStore. Select an image to open the full-size version.',
      screenshots: [
        ['store-01-sea.png', 'The ordinary beam and objects appearing'],
        ['store-08-blue-spectrum.png', 'Blue light and hidden reflections'],
        ['store-02-workshop.png', 'The Lighthouse Workshop'],
        ['store-06-optics.png', 'Optics and new possibilities'],
        ['store-07-storm.png', 'Before the Great Storm'],
        ['store-03-journal.png', 'A Journal of discoveries'],
        ['store-04-map.png', 'Mapping a route across the sea'],
        ['store-05-story.png', 'Encounters beyond the fog']
      ],
      closingTitle: 'See you on the shore',
      closing: 'During early access, your experiences will help us refine the pace of each voyage, the controls and the stories of the sea. We’ll announce the date and share Google Play and RuStore links here when access opens.'
    },
    {
      slug: 'development-begins', category: 'Development diary', title: 'Development has begun on Lighthouse Beyond Idle',
      image: 'news/development-cover.png', imageAlt: 'The first lighthouse beam reveals a path across a misty sea',
      summary: 'It began with a lighthouse, a beam and silhouettes in the mist. Meet the idea behind the game and see our early prototype.',
      lead: 'We’ve started making Lighthouse Beyond Idle, an atmospheric game about a keeper at the edge of reality. Here, light does more than illuminate: it brings forgotten shapes back to the sea.',
      paragraphs: [
        'It starts with a simple action: guide the beam towards a silhouette and reveal what the mist conceals. Gathered Light helps you improve the lighthouse, strengthen the Lamp and develop automation. We want brief visits to the sea to become a longer, unhurried journey.',
        'Our first builds focused on the essentials: the feel of the beam, ships appearing, understandable upgrades and saving your progress. The Workshop and Journal were already shaping the rhythm of the game — discover, improve and learn the story of this place.'
      ],
      galleryTitle: 'The early prototype',
      galleryIntro: 'These preserved screenshots come from version 0.9, the first prototype with an English interface. The original Russian prototype came earlier, in version 0.2. The interface and visuals have evolved since then. Select a screenshot to see it at full size.',
      screenshots: [
        ['prototype-sea.png', 'Prototype 0.9 · the sea and the first beam'],
        ['prototype-workshop.png', 'Prototype 0.9 · early upgrades'],
        ['prototype-journal.png', 'Prototype 0.9 · a Journal of discoveries']
      ],
      closingTitle: 'One signal at a time',
      closing: 'Next, we’ll fill the sea with more encounters, explore what light can do and find the right rhythm for each voyage. We’ll share the changes here, from the first silhouettes to the next horizon.'
    }
  ]
};
