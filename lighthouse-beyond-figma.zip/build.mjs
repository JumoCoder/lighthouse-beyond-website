// Dependency-free bilingual GitHub Pages generator. Run: node build.mjs
import {mkdirSync, readFileSync, writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname, join} from 'node:path';
import {news} from './content/news.mjs';
const root = dirname(fileURLToPath(import.meta.url));
const origin = 'https://jumocoder.github.io/lighthouse-beyond-website/';
const email = 'al.mandarinne@mail.ru';
const content = {
  ru: {
    home: '', policy: 'privacy/ru/', skip: 'К содержимому', nav: 'Навигация',
    about: 'Об игре', news: 'Новости', privacy: 'Конфиденциальность', play: 'Играть',
    title: ['Свет там', 'где кончаются', 'карты'],
    description: 'Станьте смотрителем маяка на краю реальности. Направляйте луч, собирайте свет и открывайте море — по одному сигналу за раз.',
    intro: 'Не всё потерянное<br>хочет быть найдено.',
    story: 'Станьте смотрителем маяка на краю реальности. Направляйте луч, собирайте свет и улучшайте маяк. В коротких возвращениях к морю складывается большое путешествие: новые спектры, странные встречи и следы, которые замечает только внимательный смотритель.',
    chapters: [
      ['Направьте свет', 'Проявляйте силуэты ручным лучом и развивайте автоматический. Изучайте, что скрывает каждый спектр.'],
      ['Прочтите сигналы', 'Бумажный корабль, чужой смотритель, ответная цепь. Собирайте сюжетные записи и находите связи между ними.'],
      ['Переживите шторм', 'Великий шторм начинает новое плавание. Сохраняйте осколки и открывайте новые возможности оптики.']
    ],
    quote: '«Море не стало пустым.<br>Просто мы разучились его видеть».',
    release: 'Скоро на смартфонах',
    releaseBody: 'Готовим Lighthouse Beyond Idle к выходу в Google Play и RuStore. Здесь появятся ссылки на игру.',
    planned: 'Скоро', releaseNote: 'Игра проходит тестирование. Дата выхода пока не объявлена.',
    policyLabel: 'Политика конфиденциальности', termsLabel: 'Условия предоставления услуг', cookiesLabel: 'Настройки файлов cookie',
    termsTitle: 'Условия игры', termsBody: 'Lighthouse Beyond Idle находится в разработке. Условия публичного релиза будут размещены здесь до выхода игры. Тестовая сборка на сайте не распространяется.',
    cookiesTitle: 'Файлы cookie', cookiesBody: 'Сайт не устанавливает файлы cookie и не сохраняет ваш выбор языка. Здесь нет рекламных и аналитических скриптов. Переключение RU / EN работает через обычные ссылки.',
    cookiesHost: 'GitHub Pages обрабатывает технические данные соединения при открытии сайта. Подробнее — в политике конфиденциальности.',
    footerNote: 'Lighthouse Beyond Idle · В разработке', contact: 'Связаться с разработчиком',
    back: 'Вернуться к маяку', read: 'Читать', videoLabel: 'Игровой процесс Lighthouse Beyond Idle', videoFallback: 'Видео не удалось загрузить.', videoDownload: 'Открыть видео',
    alts: {ship: 'Бумажный корабль в луче маяка', keeper: 'Чужой смотритель с погасшим фонарём', storm: 'Разбитый фонарь маяка во время шторма'},
    allNews: 'Все новости', openScreenshot: 'Открыть скриншот полностью',
  },
  en: {
    home: 'en/', policy: 'privacy/', skip: 'Skip to content', nav: 'Navigation',
    about: 'The game', news: 'News', privacy: 'Privacy', play: 'Play',
    title: ['A light beyond', 'the edge of', 'the map'],
    description: 'Become the keeper of a lighthouse at the edge of reality. Guide the beam, gather Light and discover the sea, one signal at a time.',
    intro: 'Not everything lost<br>wants to be found.',
    story: 'Become the keeper of a lighthouse at the edge of reality. Guide the beam, gather Light and improve your lighthouse. Brief returns to the sea become a longer journey: new spectra, strange encounters and traces that only an attentive keeper can see.',
    chapters: [
      ['Guide the light', 'Reveal silhouettes with your manual beam and develop the automatic one. Discover what each spectrum can uncover.'],
      ['Read the signals', 'A paper ship, a stranger at the lighthouse, an answering chain. Collect story entries and connect their clues.'],
      ['Weather the storm', 'A Great Storm begins a new voyage. Keep your Shards and unlock new possibilities in Optics.']
    ],
    quote: '“The sea did not become empty.<br>We simply forgot how to see it.”',
    release: 'Coming to your phone',
    releaseBody: 'We’re preparing Lighthouse Beyond Idle for Google Play and RuStore. Download links will appear here.',
    planned: 'Coming soon', releaseNote: 'The game is in testing. A release date has not been announced.',
    policyLabel: 'Privacy policy', termsLabel: 'Terms of service', cookiesLabel: 'Cookie settings',
    termsTitle: 'Game terms', termsBody: 'Lighthouse Beyond Idle is in development. The public release terms will be posted here before launch. Test builds are not distributed on this website.',
    cookiesTitle: 'Cookies', cookiesBody: 'This website does not set cookies or store your language choice. It has no advertising or analytics scripts. RU / EN language switching uses ordinary links.',
    cookiesHost: 'GitHub Pages processes technical connection information when you open the website. See the privacy policy for details.',
    footerNote: 'Lighthouse Beyond Idle · In development', contact: 'Contact the developer',
    back: 'Back to the lighthouse', read: 'Read', videoLabel: 'Lighthouse Beyond Idle gameplay', videoFallback: 'The video could not be loaded.', videoDownload: 'Open video',
    alts: {ship: 'A paper ship in the lighthouse beam', keeper: 'A stranger holding an unlit lantern', storm: 'The shattered lighthouse lantern room during a storm'},
    allNews: 'All news', openScreenshot: 'Open full-size screenshot',
  }
};
const escape = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
function save(path, text) {const full = join(root, path); mkdirSync(dirname(full), {recursive: true}); writeFileSync(full, text);}
function prefix(path) {return '../'.repeat(path.split('/').filter(Boolean).length);}
function newsSection(lang, path, limit) {
  const t = content[lang], p = prefix(path), items = limit ? news[lang].slice(0,limit) : news[lang];
  const heading = limit ? 'h2' : 'h1', cardHeading = limit ? 'h3' : 'h2';
  return `<section class="news-section" id="news" aria-labelledby="news-title"><div class="container"><span class="star" aria-hidden="true">✦</span><${heading} class="news-title" id="news-title">${t.news}</${heading}>${limit ? `<a class="all-news" href="${p+t.home}news/">${t.allNews} ⟶</a>` : ''}<div class="news-grid">${items.map(s=>`<article class="news-card"><a class="news-link" href="${p+t.home}news/${s.slug}/"><img src="${p}assets/${s.image}" width="1600" height="900" alt="" loading="lazy"><div class="news-copy"><span class="news-category">${s.category}</span><${cardHeading}>${s.title}</${cardHeading}><p>${s.summary}</p><span class="news-arrow" aria-label="${t.read}">⟶</span></div></a></article>`).join('')}</div></div></section>`;
}
function newsArticle(lang, path, article) {
  const t = content[lang], p = prefix(path);
  const video = article.videoTitle ? `<section class="article-section video-feature" aria-labelledby="video-title"><div><h2 id="video-title">${article.videoTitle}</h2><p>${article.videoBody}</p><p class="video-caption">${article.videoCaption}</p></div><div class="article-video"><video controls playsinline preload="none" poster="${p}assets/news/${lang}/store-01-sea.png" aria-label="${t.videoLabel}"><source src="${p}assets/gameplay-${lang}.mp4" type="video/mp4"><a href="${p}assets/gameplay-${lang}.mp4">${t.videoDownload}</a></video><p class="media-error" hidden>${t.videoFallback} <a href="${p}assets/gameplay-${lang}.mp4">${t.videoDownload} ↗</a></p></div></section>` : '';
  const gallery = article.screenshots.map(([file,caption])=>`<figure class="screenshot"><a href="${p}assets/news/${lang}/${file}" target="_blank" rel="noopener" aria-label="${t.openScreenshot}: ${escape(caption)}"><img src="${p}assets/news/${lang}/${file}" width="1080" height="1920" alt="${escape(caption)}" loading="lazy"></a><figcaption>${caption}</figcaption></figure>`).join('');
  return `<main class="article-page news-article container" id="main"><a class="back-link" href="${p+t.home}news/">← ${t.news}</a><article><p class="eyebrow">${article.category}</p><h1>${article.title}</h1><p class="article-lead">${article.lead}</p><img class="article-art" src="${p}assets/${article.image}" width="1600" height="900" alt="${article.imageAlt}" fetchpriority="high"><div class="article-prose">${article.paragraphs.map(text=>`<p>${text}</p>`).join('')}</div>${video}<section class="article-section" aria-labelledby="gallery-title"><h2 id="gallery-title">${article.galleryTitle}</h2><p>${article.galleryIntro}</p><div class="screenshot-grid">${gallery}</div></section><section class="article-section article-prose"><h2>${article.closingTitle}</h2><p>${article.closing}</p></section></article><nav class="article-navigation" aria-label="${t.nav}"><a class="text-link" href="${p+t.home}news/">← ${t.allNews}</a><a class="text-link" href="${p+t.home}">${t.about} ⟶</a></nav></main>`;
}
function header(lang, path, alternate, landing = false) {
  const t = content[lang], p = prefix(path), home = p + t.home || './';
  return `<header class="header ${landing ? '' : 'header-solid'}"><div class="container header-inner">
    <a class="brand" href="${home}" aria-label="Lighthouse Beyond Idle — главная"><img src="${p}assets/figma/39-161.webp" width="145" height="69" alt="Lighthouse Beyond Idle"></a>
    <nav class="navigation" aria-label="${t.nav}"><a href="${home}"${path === t.home ? ' aria-current="page"' : ''}>${t.about}</a><a href="${p+t.home}news/"${path === t.home+'news/' ? ' aria-current="page"' : ''}>${t.news}</a><a href="${p+t.policy}">${t.privacy}</a></nav>
    <nav class="languages" aria-label="${lang === 'ru' ? 'Язык' : 'Language'}"><img src="${p}assets/figma/52-9.svg" alt="" width="20" height="20"><a lang="ru" hreflang="ru" href="${lang === 'ru' ? './' : p+alternate}" aria-label="Русский" ${lang === 'ru' ? 'aria-current="page"' : ''}>RU</a><span aria-hidden="true">|</span><a lang="en" hreflang="en" href="${lang === 'en' ? './' : p+alternate}" aria-label="English" ${lang === 'en' ? 'aria-current="page"' : ''}>EN</a></nav>
  </div></header>`;
}
function footer(lang, path) {
  const t = content[lang], p = prefix(path);
  return `<footer class="footer"><div class="container footer-inner">
    <a class="footer-brand" href="${p+t.home || './'}" aria-label="Lighthouse Beyond Idle — главная"><img src="${p}assets/figma/69-1312.webp" width="267" height="115" alt="Lighthouse Beyond Idle"></a>
    <nav class="footer-links" aria-label="${lang === 'ru' ? 'Документы' : 'Documents'}"><a href="${p+t.policy}">${t.policyLabel}</a><a href="${p+t.home}terms/">${t.termsLabel}</a></nav>
    <p class="footer-note">${t.footerNote}</p><a class="contact" href="mailto:${email}">${t.contact}</a>
  </div></footer>`;
}
function page(lang, path, alternate, title, body, landing = false, meta = {}) {
  const t = content[lang], p = prefix(path);
  const ru = lang === 'ru' ? path : alternate, en = lang === 'en' ? path : alternate;
  return `<!doctype html>
<html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#16313d"><meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'self'; script-src 'self'; img-src 'self' data:; font-src 'self'; media-src 'self'; base-uri 'none'; form-action 'none'; object-src 'none'; connect-src 'none'">
<title>${escape(title)} — Lighthouse Beyond Idle</title><meta name="description" content="${escape(meta.description || t.description)}">
<link rel="canonical" href="${origin+path}"><link rel="alternate" hreflang="ru" href="${origin+ru}"><link rel="alternate" hreflang="en" href="${origin+en}"><link rel="alternate" hreflang="x-default" href="${origin+ru}">
<meta property="og:title" content="${escape(title)} — Lighthouse Beyond Idle"><meta property="og:description" content="${escape(meta.description || t.description)}"><meta property="og:type" content="${meta.type || 'website'}"><meta property="og:url" content="${origin+path}"><meta property="og:image" content="${origin}assets/${meta.image || 'figma/91-34.webp'}">
<link rel="icon" href="${p}assets/beacon.svg" type="image/svg+xml"><link rel="preload" href="${p}assets/fonts/Neucha.ttf" as="font" type="font/ttf" crossorigin><link rel="stylesheet" href="${p}assets/site.css"><script src="${p}assets/site.js" defer></script>
</head><body id="top" class="${landing ? 'landing' : 'inner-page'}"><a class="skip" href="#main">${t.skip}</a>${header(lang,path,alternate,landing)}${body}${footer(lang,path)}</body></html>\n`;
}
for (const lang of ['ru', 'en']) {
  const t = content[lang], p = prefix(t.home), other = content[lang === 'ru' ? 'en' : 'ru'];
  const star = '<span class="star" aria-hidden="true">✦</span>';
  const body = `<main id="main">
    <section class="hero" aria-labelledby="hero-title"><img class="hero-art" src="${p}assets/figma/91-34.webp" width="1400" height="1010" alt="" fetchpriority="high"><div class="container hero-inner"><h1 id="hero-title"><span>${t.title[0]}</span><span>${t.title[1]}</span><span class="title-end">${star}${t.title[2]}</span></h1><a class="play-button" href="#release">${t.play}</a></div></section>
    <section class="about" id="story" aria-labelledby="story-title"><div class="container collage">
      <img class="collage-ship" src="${p}assets/paper-ship.jpg" width="1920" height="1080" alt="${t.alts.ship}" loading="lazy">
      <h2 id="story-title">${t.intro}</h2>
      <img class="collage-keeper" src="${p}assets/keeper-current.jpg" width="2752" height="1536" alt="${t.alts.keeper}" loading="lazy">
      <div class="gameplay"><video controls playsinline preload="none" poster="${p}assets/gameplay-${lang}.png" aria-label="${t.videoLabel}"><source src="${p}assets/gameplay-${lang}.mp4" type="video/mp4"><a href="${p}assets/gameplay-${lang}.mp4">${t.videoDownload}</a></video><p class="media-error" hidden>${t.videoFallback} <a href="${p}assets/gameplay-${lang}.mp4">${t.videoDownload} ↗</a></p></div>
      <p class="story-copy">${t.story}</p>
      <img class="collage-storm" src="${p}assets/broken-lighthouse.jpg" width="2752" height="1536" alt="${t.alts.storm}" loading="lazy">
    </div></section>
    <section class="journey container" aria-label="${t.about}">${t.chapters.map(([title,desc],i)=>`<article class="chapter"><span class="number" aria-hidden="true">${i+1}.</span><h3>${title}</h3><p>${desc}</p></article>`).join('')}</section>
    ${newsSection(lang,t.home,3)}
    <section class="release" id="release" aria-labelledby="release-title"><div class="container release-inner">${star}<blockquote>${t.quote}</blockquote><h2 id="release-title">${t.release}</h2><p class="release-copy">${t.releaseBody}</p><div class="stores"><div class="store" aria-label="Google Play — ${t.planned}"><img src="${p}assets/google-play.svg" alt="Google Play" width="243" height="56"><span>${t.planned}</span></div><div class="store" aria-label="RuStore — ${t.planned}"><img src="${p}assets/rustore.svg" alt="RuStore" width="253" height="64"><span>${t.planned}</span></div></div><p class="release-note">${t.releaseNote}</p></div></section>
  </main>`;
  save(t.home+'index.html', page(lang,t.home,other.home,t.title.join(' '),body,true));
  const newsPath = t.home+'news/';
  save(newsPath+'index.html', page(lang,newsPath,other.home+'news/',t.news,`<main class="news-page" id="main">${newsSection(lang,newsPath)}</main>`));
  for (const article of news[lang]) {
    const path = t.home+`news/${article.slug}/`, alt = other.home+`news/${article.slug}/`;
    save(path+'index.html',page(lang,path,alt,article.title,newsArticle(lang,path,article),false,{description:article.summary,image:article.image,type:'article'}));
  }
  for (const type of ['terms','cookies']) {
    const path = t.home+type+'/', alt = other.home+type+'/', pp = prefix(path);
    save(path+'index.html',page(lang,path,alt,t[type+'Title'],`<main class="article-page text-page container" id="main"><a class="back-link" href="${pp+t.home || '../'}">← ${t.back}</a><h1>${t[type+'Title']}</h1><p>${t[type+'Body']}</p>${type === 'cookies' ? `<p>${t.cookiesHost}</p><a class="text-link" href="${pp+t.policy}">${t.policyLabel} ⟶</a>` : `<a class="text-link" href="mailto:${email}">${t.contact} ⟶</a>`}</main>`));
  }
}
// Existing policy copy stays a draft. Its body is separate from the new shell.
for (const lang of ['ru','en']) {
  const t=content[lang],other=content[lang==='ru'?'en':'ru'];
  const source=readFileSync(join(root,`content/privacy-${lang}.html`),'utf8').replaceAll('al.mandarinne@gmail.com',email);
  save(t.policy+'index.html',page(lang,t.policy,other.policy,t.policyLabel,source));
}
const notFound=page('ru','','en/','Сигнал потерян',`<main class="article-page text-page container" id="main"><p class="eyebrow">404</p><h1>Сигнал потерян</h1><p>Такой страницы нет. Вернёмся к маяку?</p><a class="text-link" href="./">На главную ⟶</a></main>`);
save('404.html',notFound.replace(/(href|src)="(?!https?:|mailto:|#)([^"]*)"/g,(_,attr,value)=>`${attr}="${new URL(value,origin).pathname}${new URL(value,origin).hash}"`));
const routes = ['', 'en/', 'privacy/', 'privacy/ru/'];
for (const [lang,t] of Object.entries(content)) routes.push(t.home+'news/',t.home+'terms/',t.home+'cookies/',...news[lang].map(s=>t.home+`news/${s.slug}/`));
save('sitemap.xml','<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+routes.map(path=>`<url><loc>${origin+path}</loc></url>`).join('')+'</urlset>\n');
console.log(`Built ${routes.length} pages with relative GitHub Pages paths.`);
